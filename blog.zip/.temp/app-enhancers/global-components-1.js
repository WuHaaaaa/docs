import Vue from 'vue'

Vue.component("Badge", () => import("E:\\Coder\\blog\\node_modules\\@vuepress\\theme-default\\global-components\\Badge"))
Vue.component("CodeBlock", () => import("E:\\Coder\\blog\\node_modules\\@vuepress\\theme-default\\global-components\\CodeBlock"))
Vue.component("CodeGroup", () => import("E:\\Coder\\blog\\node_modules\\@vuepress\\theme-default\\global-components\\CodeGroup"))


export default {}