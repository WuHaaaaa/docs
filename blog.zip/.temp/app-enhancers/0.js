import "E:\\Coder\\blog\\node_modules\\@vuepress\\core\\lib\\node\\internal-plugins\\style\\client.js"
export default {}