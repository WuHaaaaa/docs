export default [
  "SWUpdatePopup",
  "BackToTop"
]